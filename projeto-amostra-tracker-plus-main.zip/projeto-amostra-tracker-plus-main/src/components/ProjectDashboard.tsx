
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Project } from '@/types/project';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Printer } from 'lucide-react';

interface ProjectDashboardProps {
  projects: Project[];
}

export function ProjectDashboard({ projects }: ProjectDashboardProps) {
  // Dados por responsável
  const projectsByResponsible = projects.reduce((acc, project) => {
    const existing = acc.find(item => item.responsavel === project.responsavel);
    if (existing) {
      existing.total++;
      existing[project.status]++;
    } else {
      acc.push({
        responsavel: project.responsavel,
        total: 1,
        EM_ANDAMENTO: project.status === 'EM_ANDAMENTO' ? 1 : 0,
        APROVADO: project.status === 'APROVADO' ? 1 : 0,
        REPROVADO: project.status === 'REPROVADO' ? 1 : 0,
      });
    }
    return acc;
  }, [] as any[]);

  // Dados por status
  const statusData = [
    { name: 'Em Andamento', value: projects.filter(p => p.status === 'EM_ANDAMENTO').length, color: '#3b82f6' },
    { name: 'Aprovado', value: projects.filter(p => p.status === 'APROVADO').length, color: '#10b981' },
    { name: 'Reprovado', value: projects.filter(p => p.status === 'REPROVADO').length, color: '#ef4444' },
  ];

  // Função para gerar relatório
  const generateReport = () => {
    const reportContent = `
      RELATÓRIO DE CONTROLE DE AMOSTRAS DE PROJETOS
      =============================================
      
      Data: ${new Date().toLocaleDateString('pt-BR')}
      
      RESUMO GERAL:
      - Total de Projetos: ${projects.length}
      - Em Andamento: ${projects.filter(p => p.status === 'EM_ANDAMENTO').length}
      - Aprovados: ${projects.filter(p => p.status === 'APROVADO').length}
      - Reprovados: ${projects.filter(p => p.status === 'REPROVADO').length}
      
      PROJETOS POR RESPONSÁVEL:
      ${projectsByResponsible.map(resp => 
        `- ${resp.responsavel}: ${resp.total} projetos (${resp.EM_ANDAMENTO} em andamento, ${resp.APROVADO} aprovados, ${resp.REPROVADO} reprovados)`
      ).join('\n      ')}
      
      DETALHES DOS PROJETOS:
      ${projects.map(project => 
        `
      Projeto: ${project.projeto} (#${project.numeroProject})
      Responsável: ${project.responsavel}
      Status: ${project.status === 'EM_ANDAMENTO' ? 'Em Andamento' : project.status === 'APROVADO' ? 'Aprovado' : 'Reprovado'}
      Início: ${project.inicioProject.toLocaleDateString('pt-BR')}
      Lead Time: ${project.leadTime} dias
      ${project.descricao ? `Descrição: ${project.descricao}` : ''}
      `).join('\n')}
    `;

    // Criar nova janela para impressão
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Relatório de Projetos</title>
            <style>
              body { font-family: monospace; padding: 20px; }
              pre { white-space: pre-wrap; }
              @media print {
                body { margin: 0; }
              }
            </style>
          </head>
          <body>
            <pre>${reportContent}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Dashboard</h2>
        <Button onClick={generateReport} className="flex items-center gap-2">
          <Printer className="h-4 w-4" />
          Gerar Relatório
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Total de Projetos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{projects.length}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Em Andamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">
              {projects.filter(p => p.status === 'EM_ANDAMENTO').length}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Aprovados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {projects.filter(p => p.status === 'APROVADO').length}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Projetos por Responsável</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={projectsByResponsible}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="responsavel" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="total" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Status dos Projetos</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
