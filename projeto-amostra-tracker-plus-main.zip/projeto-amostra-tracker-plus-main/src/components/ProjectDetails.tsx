
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PasswordDialog } from '@/components/PasswordDialog';
import { Project, Product } from '@/types/project';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Package, Edit, Save, X, Calendar as CalendarIcon, Trash2, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface ProjectDetailsProps {
  project: Project;
  products: Product[];
  onAddProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  onUpdateProject: (project: Project) => void;
  onUpdateProducts: (products: Product[]) => void;
}

export function ProjectDetails({ project, products, onAddProduct, onUpdateProject, onUpdateProducts }: ProjectDetailsProps) {
  const [newProductName, setNewProductName] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [editProductName, setEditProductName] = useState('');
  const [editData, setEditData] = useState({
    projeto: project.projeto,
    responsavel: project.responsavel,
    descricao: project.descricao,
    inicioProject: project.inicioProject,
    leadTime: project.leadTime,
    status: project.status
  });
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();

  const requireAuth = (action: () => void) => {
    if (isAuthenticated) {
      action();
    } else {
      setPendingAction(() => action);
      setShowPasswordDialog(true);
    }
  };

  const handleAuthSuccess = () => {
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const handleAddProduct = () => {
    const action = () => {
      if (!newProductName.trim()) {
        toast({
          title: "Erro",
          description: "Digite o nome do produto",
          variant: "destructive",
        });
        return;
      }

      onAddProduct({
        projectId: project.id,
        nome: newProductName.trim(),
      });

      setNewProductName('');
      toast({
        title: "Sucesso",
        description: "Produto adicionado com sucesso!",
      });
    };

    requireAuth(action);
  };

  const handleEditProduct = (productId: string, currentName: string) => {
    setEditingProduct(productId);
    setEditProductName(currentName);
  };

  const handleSaveProduct = (productId: string) => {
    const action = () => {
      if (!editProductName.trim()) {
        toast({
          title: "Erro",
          description: "Digite o nome do produto",
          variant: "destructive",
        });
        return;
      }

      const updatedProducts = products.map(p => 
        p.id === productId ? { ...p, nome: editProductName.trim() } : p
      );
      
      onUpdateProducts(updatedProducts);
      setEditingProduct(null);
      setEditProductName('');
      
      toast({
        title: "Sucesso",
        description: "Produto atualizado com sucesso!",
      });
    };

    requireAuth(action);
  };

  const handleDeleteProduct = (productId: string) => {
    const action = () => {
      const updatedProducts = products.filter(p => p.id !== productId);
      onUpdateProducts(updatedProducts);
      
      toast({
        title: "Sucesso",
        description: "Produto removido com sucesso!",
      });
    };

    requireAuth(action);
  };

  const handleEditProject = () => {
    const action = () => setIsEditing(true);
    requireAuth(action);
  };

  const handleSaveEdit = () => {
    const updatedProject = {
      ...project,
      ...editData,
      updatedAt: new Date()
    };
    
    onUpdateProject(updatedProject);
    setIsEditing(false);
    
    toast({
      title: "Sucesso",
      description: "Projeto atualizado com sucesso!",
    });
  };

  const handleCancelEdit = () => {
    setEditData({
      projeto: project.projeto,
      responsavel: project.responsavel,
      descricao: project.descricao,
      inicioProject: project.inicioProject,
      leadTime: project.leadTime,
      status: project.status
    });
    setIsEditing(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'EM_ANDAMENTO':
        return 'bg-blue-500';
      case 'APROVADO':
        return 'bg-green-500';
      case 'REPROVADO':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'EM_ANDAMENTO':
        return 'Em Andamento';
      case 'APROVADO':
        return 'Aprovado';
      case 'REPROVADO':
        return 'Reprovado';
      default:
        return status;
    }
  };

  const projectProducts = products.filter(p => p.projectId === project.id);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex-1">
              {isEditing ? (
                <div className="space-y-2">
                  <Input
                    value={editData.projeto}
                    onChange={(e) => setEditData({ ...editData, projeto: e.target.value })}
                    className="text-2xl font-bold"
                  />
                  <p className="text-muted-foreground">#{project.numeroProject}</p>
                </div>
              ) : (
                <div>
                  <CardTitle className="text-2xl">{project.projeto}</CardTitle>
                  <p className="text-muted-foreground">#{project.numeroProject}</p>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {isEditing ? (
                <Badge className={getStatusColor(editData.status)}>
                  {getStatusText(editData.status)}
                </Badge>
              ) : (
                <Badge className={getStatusColor(project.status)}>
                  {getStatusText(project.status)}
                </Badge>
              )}
              {isEditing ? (
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleSaveEdit}>
                    <Save className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button size="sm" variant="outline" onClick={handleEditProject}>
                  <Edit className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isEditing ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Responsável</Label>
                  <Input
                    value={editData.responsavel}
                    onChange={(e) => setEditData({ ...editData, responsavel: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium">Início do Projeto</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !editData.inicioProject && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {editData.inicioProject ? format(editData.inicioProject, "dd/MM/yyyy") : "Selecionar data"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={editData.inicioProject}
                        onSelect={(date) => setEditData({ ...editData, inicioProject: date || new Date() })}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <Label className="text-sm font-medium">Lead Time</Label>
                  <Select 
                    value={editData.leadTime.toString()} 
                    onValueChange={(value) => setEditData({ ...editData, leadTime: parseInt(value) as 120 | 240 | 350 })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="120">120 dias</SelectItem>
                      <SelectItem value="240">240 dias</SelectItem>
                      <SelectItem value="350">350 dias</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-sm font-medium">Status</Label>
                  <Select 
                    value={editData.status} 
                    onValueChange={(value: string) => setEditData({ ...editData, status: value as 'EM_ANDAMENTO' | 'APROVADO' | 'REPROVADO' })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EM_ANDAMENTO">Em Andamento</SelectItem>
                      <SelectItem value="APROVADO">Aprovado</SelectItem>
                      <SelectItem value="REPROVADO">Reprovado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">Descrição</Label>
                <Textarea
                  value={editData.descricao}
                  onChange={(e) => setEditData({ ...editData, descricao: e.target.value })}
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">Responsável</Label>
                <p className="text-sm">{project.responsavel}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Início do Projeto</Label>
                <p className="text-sm">{format(project.inicioProject, 'dd/MM/yyyy', { locale: ptBR })}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Lead Time</Label>
                <p className="text-sm">{project.leadTime} dias</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Data de Finalização</Label>
                <p className="text-sm">
                  {format(
                    new Date(project.inicioProject.getTime() + project.leadTime * 24 * 60 * 60 * 1000),
                    'dd/MM/yyyy',
                    { locale: ptBR }
                  )}
                </p>
              </div>
              {project.descricao && (
                <div className="md:col-span-2">
                  <Label className="text-sm font-medium">Descrição</Label>
                  <p className="text-sm mt-1">{project.descricao}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Produtos ({projectProducts.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Nome do produto"
              value={newProductName}
              onChange={(e) => setNewProductName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddProduct()}
            />
            <Button onClick={handleAddProduct}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          {projectProducts.length > 0 ? (
            <div className="grid gap-2">
              {projectProducts.map((product) => (
                <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                  {editingProduct === product.id ? (
                    <div className="flex-1 flex items-center gap-2">
                      <Input
                        value={editProductName}
                        onChange={(e) => setEditProductName(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSaveProduct(product.id)}
                        className="flex-1"
                      />
                      <Button 
                        size="sm" 
                        onClick={() => handleSaveProduct(product.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => setEditingProduct(null)}
                        className="h-8 w-8 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="flex-1">
                        <span>{product.nome}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {format(product.createdAt, 'dd/MM/yyyy', { locale: ptBR })}
                        </span>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleEditProduct(product.id, product.nome)}
                          className="h-8 w-8 p-0"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={() => handleDeleteProduct(product.id)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-4">
              Nenhum produto cadastrado para este projeto
            </p>
          )}
        </CardContent>
      </Card>

      <PasswordDialog 
        isOpen={showPasswordDialog}
        onClose={() => setShowPasswordDialog(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}
