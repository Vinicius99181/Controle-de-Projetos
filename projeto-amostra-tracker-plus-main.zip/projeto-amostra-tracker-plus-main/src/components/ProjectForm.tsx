import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Calendar as CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Project } from '@/types/project';
import { useToast } from '@/hooks/use-toast';

interface ProjectFormProps {
  onSubmit: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export function ProjectForm({ onSubmit }: ProjectFormProps) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    numeroProject: '',
    projeto: '',
    responsavel: '',
    descricao: '',
    inicioProject: undefined as Date | undefined,
    leadTime: undefined as 120 | 240 | 350 | undefined,
    status: 'EM_ANDAMENTO' as 'EM_ANDAMENTO' | 'APROVADO' | 'REPROVADO',
  });
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Descrição agora é opcional
    if (!formData.numeroProject || !formData.projeto || !formData.responsavel || 
        !formData.inicioProject || !formData.leadTime) {
      toast({
        title: "Erro",
        description: "Todos os campos obrigatórios devem ser preenchidos (descrição é opcional)",
        variant: "destructive",
      });
      return;
    }

    onSubmit(formData as Omit<Project, 'id' | 'createdAt' | 'updatedAt'>);
    
    // Reset form
    setFormData({
      numeroProject: '',
      projeto: '',
      responsavel: '',
      descricao: '',
      inicioProject: undefined,
      leadTime: undefined,
      status: 'EM_ANDAMENTO',
    });
    
    setOpen(false);
    
    toast({
      title: "Sucesso",
      description: "Projeto criado com sucesso!",
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          size="icon" 
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Novo Projeto</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="numeroProject">Nº do Projeto *</Label>
              <Input
                id="numeroProject"
                value={formData.numeroProject}
                onChange={(e) => setFormData({ ...formData, numeroProject: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="projeto">Projeto *</Label>
              <Input
                id="projeto"
                value={formData.projeto}
                onChange={(e) => setFormData({ ...formData, projeto: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="responsavel">Responsável *</Label>
            <Input
              id="responsavel"
              value={formData.responsavel}
              onChange={(e) => setFormData({ ...formData, responsavel: e.target.value })}
              required
            />
          </div>

          <div>
            <Label htmlFor="descricao">Descrição (Opcional)</Label>
            <Textarea
              id="descricao"
              value={formData.descricao}
              onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Início do Projeto *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !formData.inicioProject && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.inicioProject ? format(formData.inicioProject, "dd/MM/yyyy") : "Selecionar data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.inicioProject}
                    onSelect={(date) => setFormData({ ...formData, inicioProject: date })}
                    className="pointer-events-auto"
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>Lead Time *</Label>
              <Select onValueChange={(value) => setFormData({ ...formData, leadTime: parseInt(value) as 120 | 240 | 350 })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar lead time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="120">120 dias</SelectItem>
                  <SelectItem value="240">240 dias</SelectItem>
                  <SelectItem value="350">350 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Status</Label>
            <Select 
              value={formData.status} 
              onValueChange={(value: string) => setFormData({ ...formData, status: value as 'EM_ANDAMENTO' | 'APROVADO' | 'REPROVADO' })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="EM_ANDAMENTO">Em Andamento</SelectItem>
                <SelectItem value="APROVADO">Aprovado</SelectItem>
                <SelectItem value="REPROVADO">Reprovado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              Criar Projeto
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
