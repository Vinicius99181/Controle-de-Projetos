
import React, { useState } from 'react';
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from '@/components/ui/sidebar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Project } from '@/types/project';
import { cn } from '@/lib/utils';

interface ProjectSidebarProps {
  projects: Project[];
  selectedProject: Project | null;
  onSelectProject: (project: Project) => void;
  sidebarColor: string;
}

export function ProjectSidebar({ projects, selectedProject, onSelectProject, sidebarColor }: ProjectSidebarProps) {
  const [selectedResponsavel, setSelectedResponsavel] = useState<string>('all');

  // Ordenar projetos por numeração
  const sortedProjects = [...projects].sort((a, b) => {
    const numA = parseInt(a.numeroProject) || 0;
    const numB = parseInt(b.numeroProject) || 0;
    return numA - numB;
  });

  // Filtrar por responsável se selecionado
  const filteredProjects = selectedResponsavel === 'all' 
    ? sortedProjects
    : sortedProjects.filter(project => project.responsavel === selectedResponsavel);

  // Obter lista única de responsáveis
  const responsaveis = [...new Set(projects.map(p => p.responsavel))].sort();

  return (
    <Sidebar style={{ backgroundColor: sidebarColor }} className="border-r">
      <SidebarContent style={{ backgroundColor: sidebarColor }}>
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground">Filtros</SidebarGroupLabel>
          <SidebarGroupContent>
            <div className="p-2">
              <Select value={selectedResponsavel} onValueChange={setSelectedResponsavel}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Filtrar por responsável" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os responsáveis</SelectItem>
                  {responsaveis.map((responsavel) => (
                    <SelectItem key={responsavel} value={responsavel}>
                      {responsavel}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>
        
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground">
            Projetos ({filteredProjects.length})
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredProjects.map((project) => (
                <SidebarMenuItem key={project.id}>
                  <SidebarMenuButton
                    onClick={() => onSelectProject(project)}
                    className={cn(
                      "w-full justify-start",
                      selectedProject?.id === project.id && "bg-sidebar-accent text-sidebar-accent-foreground"
                    )}
                  >
                    <div className="flex flex-col items-start">
                      <span className="font-medium">{project.projeto}</span>
                      <span className="text-xs text-muted-foreground">#{project.numeroProject}</span>
                    </div>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
