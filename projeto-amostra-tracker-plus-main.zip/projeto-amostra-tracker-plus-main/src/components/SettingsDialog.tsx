
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Palette, Mail, Plus, X } from 'lucide-react';
import { AppSettings, EmailConfig } from '@/types/project';
import { useToast } from '@/hooks/use-toast';

interface SettingsDialogProps {
  settings: AppSettings;
  emails: EmailConfig[];
  onUpdateSettings: (settings: AppSettings) => void;
  onUpdateEmails: (emails: EmailConfig[]) => void;
}

export function SettingsDialog({ settings, emails, onUpdateSettings, onUpdateEmails }: SettingsDialogProps) {
  const [open, setOpen] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const { toast } = useToast();

  const handleAddEmail = () => {
    if (!newEmail.trim()) return;
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newEmail)) {
      toast({
        title: "Erro",
        description: "Email inválido",
        variant: "destructive",
      });
      return;
    }

    const newEmailConfig: EmailConfig = {
      id: Date.now().toString(),
      email: newEmail.trim(),
      isActive: true,
    };

    onUpdateEmails([...emails, newEmailConfig]);
    setNewEmail('');
    
    toast({
      title: "Sucesso",
      description: "Email adicionado com sucesso!",
    });
  };

  const handleRemoveEmail = (emailId: string) => {
    onUpdateEmails(emails.filter(e => e.id !== emailId));
  };

  const handleToggleEmail = (emailId: string) => {
    onUpdateEmails(
      emails.map(e => e.id === emailId ? { ...e, isActive: !e.isActive } : e)
    );
  };

  const predefinedColors = [
    { name: 'Padrão', value: 'hsl(var(--sidebar-background))' },
    { name: 'Azul', value: '#1e40af' },
    { name: 'Verde', value: '#16a34a' },
    { name: 'Roxo', value: '#7c3aed' },
    { name: 'Vermelho', value: '#dc2626' },
    { name: 'Laranja', value: '#ea580c' },
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Configurações</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Tema */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Tema
            </Label>
            <Select 
              value={settings.theme} 
              onValueChange={(value) => onUpdateSettings({ ...settings, theme: value as 'light' | 'dark' | 'normal' })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="normal">Modo Normal</SelectItem>
                <SelectItem value="dark">Modo Escuro</SelectItem>
                <SelectItem value="light">Modo Claro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Cor do Menu Lateral */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Cor do Menu Lateral</Label>
            <div className="grid grid-cols-3 gap-2">
              {predefinedColors.map((color) => (
                <Button
                  key={color.name}
                  variant={settings.sidebarColor === color.value ? "default" : "outline"}
                  className="h-12"
                  style={{ backgroundColor: color.value !== 'hsl(var(--sidebar-background))' ? color.value : undefined }}
                  onClick={() => onUpdateSettings({ ...settings, sidebarColor: color.value })}
                >
                  {color.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Emails */}
          <div className="space-y-3">
            <Label className="text-base font-medium flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Emails para Notificações
            </Label>
            
            <div className="flex gap-2">
              <Input
                placeholder="email@exemplo.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddEmail()}
              />
              <Button onClick={handleAddEmail}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-2">
              {emails.map((email) => (
                <div key={email.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={email.isActive}
                      onChange={() => handleToggleEmail(email.id)}
                      className="rounded"
                    />
                    <span className={!email.isActive ? 'text-muted-foreground line-through' : ''}>
                      {email.email}
                    </span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleRemoveEmail(email.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>

            {emails.length === 0 && (
              <p className="text-muted-foreground text-center py-4">
                Nenhum email configurado
              </p>
            )}
          </div>
        </div>

        <div className="flex justify-end pt-4">
          <Button onClick={() => setOpen(false)}>
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
