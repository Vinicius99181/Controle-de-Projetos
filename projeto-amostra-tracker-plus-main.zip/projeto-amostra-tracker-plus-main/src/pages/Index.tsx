
import ProjectManagement from './ProjectManagement';

const Index = () => {
  return <ProjectManagement />;
};

export default Index;
