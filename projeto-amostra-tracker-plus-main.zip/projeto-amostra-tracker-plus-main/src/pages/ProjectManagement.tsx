
import React, { useState, useEffect } from 'react';
import { SidebarProvider, SidebarInset, SidebarTrigger } from '@/components/ui/sidebar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ProjectSidebar } from '@/components/ProjectSidebar';
import { ProjectForm } from '@/components/ProjectForm';
import { ProjectDetails } from '@/components/ProjectDetails';
import { ProjectDashboard } from '@/components/ProjectDashboard';
import { SettingsDialog } from '@/components/SettingsDialog';
import { AuthProvider } from '@/contexts/AuthContext';
import { Project, Product, EmailConfig, AppSettings } from '@/types/project';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';
import { BarChart3, FolderOpen } from 'lucide-react';

export default function ProjectManagement() {
  const [projectsRaw, setProjectsRaw] = useLocalStorage<Project[]>('projects', []);
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [emails, setEmails] = useLocalStorage<EmailConfig[]>('emails', [
    { id: '1', email: 'vinicius.batista@santecosmetica.com.br', isActive: true }
  ]);
  const [settings, setSettings] = useLocalStorage<AppSettings>('settings', {
    theme: 'normal',
    sidebarColor: '#09090b'
  });
  
  // Convert date strings back to Date objects with safety checks
  const projects = projectsRaw.map(project => {
    try {
      return {
        ...project,
        inicioProject: project.inicioProject instanceof Date ? project.inicioProject : new Date(project.inicioProject),
        createdAt: project.createdAt instanceof Date ? project.createdAt : new Date(project.createdAt),
        updatedAt: project.updatedAt instanceof Date ? project.updatedAt : new Date(project.updatedAt)
      };
    } catch (error) {
      console.error('Error converting project dates:', error, project);
      // Return project with current date as fallback
      return {
        ...project,
        inicioProject: new Date(),
        createdAt: new Date(),
        updatedAt: new Date()
      };
    }
  });

  const setProjects = (newProjects: Project[]) => {
    setProjectsRaw(newProjects);
  };
  
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const { toast } = useToast();

  // Aplicar tema
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  // Aplicar cor do sidebar
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--sidebar-background', settings.sidebarColor);
  }, [settings.sidebarColor]);

  // Verificar lead times vencidos
  useEffect(() => {
    const checkOverdueProjects = () => {
      try {
        const now = new Date();
        const overdueProjects = projects.filter(project => {
          try {
            const deadline = new Date(project.inicioProject.getTime() + project.leadTime * 24 * 60 * 60 * 1000);
            return now > deadline && project.status === 'EM_ANDAMENTO';
          } catch (error) {
            console.error('Error checking project deadline:', error, project);
            return false;
          }
        });

        if (overdueProjects.length > 0) {
          const activeEmails = emails.filter(e => e.isActive);
          if (activeEmails.length > 0) {
            // Simular envio de email (em produção, isso seria feito via backend)
            const emailList = activeEmails.map(e => e.email).join(', ');
            const projectList = overdueProjects.map(p => `${p.projeto} (#${p.numeroProject})`).join(', ');
            
            toast({
              title: "Projetos Vencidos Detectados",
              description: `${overdueProjects.length} projeto(s) vencido(s): ${projectList}. Emails enviados para: ${emailList}`,
              variant: "destructive",
            });
            
            console.log('Email enviado para:', emailList);
            console.log('Projetos vencidos:', overdueProjects);
          }
        }
      } catch (error) {
        console.error('Error in checkOverdueProjects:', error);
      }
    };

    // Verificar a cada hora
    const interval = setInterval(checkOverdueProjects, 60 * 60 * 1000);
    
    // Verificar imediatamente na inicialização
    checkOverdueProjects();

    return () => clearInterval(interval);
  }, [projects, emails, toast]);

  const handleCreateProject = (projectData: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    setProjects([...projects, newProject]);
  };

  const handleUpdateProject = (updatedProject: Project) => {
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
    
    // Atualizar projeto selecionado se for o mesmo
    if (selectedProject?.id === updatedProject.id) {
      setSelectedProject(updatedProject);
    }
  };

  const handleAddProduct = (productData: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    
    setProducts([...products, newProduct]);
  };

  return (
    <AuthProvider>
      <div className={`min-h-screen w-full ${settings.theme === 'dark' ? 'dark' : ''}`}>
        <SidebarProvider>
          <div className="min-h-screen flex w-full">
            <ProjectSidebar
              projects={projects}
              selectedProject={selectedProject}
              onSelectProject={setSelectedProject}
              sidebarColor={settings.sidebarColor}
            />
            <SidebarInset>
              <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
                <SidebarTrigger className="-ml-1" />
                <div className="flex flex-1 justify-between items-center">
                  <h1 className="text-xl font-semibold">Controle de Amostras de Projetos</h1>
                  <SettingsDialog
                    settings={settings}
                    emails={emails}
                    onUpdateSettings={setSettings}
                    onUpdateEmails={setEmails}
                  />
                </div>
              </header>
              
              <main className="flex-1 p-6">
                <Tabs defaultValue="dashboard" className="w-full">
                  <TabsList>
                    <TabsTrigger value="dashboard" className="flex items-center gap-2">
                      <BarChart3 className="h-4 w-4" />
                      Dashboard
                    </TabsTrigger>
                    <TabsTrigger value="project" className="flex items-center gap-2">
                      <FolderOpen className="h-4 w-4" />
                      Projeto
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="dashboard" className="mt-6">
                    <ProjectDashboard projects={projects} />
                  </TabsContent>
                  
                  <TabsContent value="project" className="mt-6">
                    {selectedProject ? (
                      <ProjectDetails
                        project={selectedProject}
                        products={products}
                        onAddProduct={handleAddProduct}
                        onUpdateProject={handleUpdateProject}
                        onUpdateProducts={setProducts}
                      />
                    ) : (
                      <div className="text-center py-12">
                        <FolderOpen className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium mb-2">Nenhum projeto selecionado</h3>
                        <p className="text-muted-foreground">
                          Selecione um projeto no menu lateral para visualizar os detalhes
                        </p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </main>
            </SidebarInset>
          </div>
          
          <ProjectForm onSubmit={handleCreateProject} />
        </SidebarProvider>
      </div>
    </AuthProvider>
  );
}
