
export interface Project {
  id: string;
  numeroProject: string;
  projeto: string;
  responsavel: string;
  descricao: string;
  inicioProject: Date;
  leadTime: 120 | 240 | 350;
  status: 'EM_ANDAMENTO' | 'APROVADO' | 'REPROVADO';
  createdAt: Date;
  updatedAt: Date;
}

export interface Product {
  id: string;
  projectId: string;
  nome: string;
  createdAt: Date;
}

export interface EmailConfig {
  id: string;
  email: string;
  isActive: boolean;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'normal';
  sidebarColor: string;
}
